# Deep MSM archive inspection

Run: 2026-11-04T00:36:55.384830+00:00

Archive sources were publicly available; binary content was not committed.

## 2021 PC Windows archives

Status: completed

### [WIN] My Singing Monsters [Manifest 2046132612292651817] [2021-05-18] .7z

Downloaded bytes: 11127240.
Listed items: 5.
Error: none.

- MySingingMonsters.exp (2833 bytes)
- MySingingMonsters.iobj (72729955 bytes)
- MySingingMonsters.ipdb (13303504 bytes)
- MySingingMonsters.lib (5658 bytes)
- MySingingMonsters.exe (5782016 bytes)
### [WIN] My Singing Monsters [Manifest 4651787433336000098] [2021-04-21].7z

Downloaded bytes: 11135464.
Listed items: 6.
Error: none.

- MySingingMonsters.exe.metagen (8527 bytes)
- MySingingMonsters.exp (2833 bytes)
- MySingingMonsters.iobj (72721676 bytes)
- MySingingMonsters.ipdb (13301936 bytes)
- MySingingMonsters.lib (5658 bytes)
- MySingingMonsters.exe (5780480 bytes)

## Official Guide DLC

### dlc/1280 (1.3.0)/android/Server

Downloaded 1220 bytes. SHA-1 verified: True.
Unity objects: 2.
Object types: {'AssetBundle': 1, 'AssetBundleManifest': 1}.
Error: none.

- AssetBundleManifest: AssetBundleManifest
### dlc/1280 (1.3.0)/android/data.unity3d

Downloaded 49999 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoScript': 2, 'MonoBehaviour': 2, 'AssetBundle': 1}.
Error: none.

- MonoScript: UISettings
- MonoBehaviour: UISettings
- AssetBundle: data.unity3d
- MonoScript: AllData
- MonoBehaviour: AllData
### dlc/1280 (1.3.0)/android/localization.unity3d

Downloaded 8715 bytes. SHA-1 verified: True.
Unity objects: 13.
Object types: {'MonoBehaviour': 8, 'MonoScript': 4, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: de
- MonoBehaviour: it
- MonoBehaviour: settings
- MonoScript: BBBMasterText
- MonoBehaviour: _master_text
- MonoBehaviour: localization
- MonoScript: BBBLanguageData
- MonoScript: BBBLocalizerSettings
- AssetBundle: localization.unity3d
- MonoScript: BBBLocalizerConfig
- MonoBehaviour: es
- MonoBehaviour: fr
- MonoBehaviour: en
### dlc/1280 (1.3.0)/android/master.unity3d

Downloaded 351855 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoBehaviour': 2, 'MonoScript': 2, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: GlobalBundleData
- MonoScript: GlobalBundleData
- MonoBehaviour: GlobalLookupData
- AssetBundle: master.unity3d
- MonoScript: GlobalLookupData
### dlc/1383 (sept 26 2019)/android/Server

Downloaded 1252 bytes. SHA-1 verified: True.
Unity objects: 2.
Object types: {'AssetBundle': 1, 'AssetBundleManifest': 1}.
Error: none.

- AssetBundleManifest: AssetBundleManifest
### dlc/1383 (sept 26 2019)/android/data.unity3d

Downloaded 62490 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoScript': 2, 'MonoBehaviour': 2, 'AssetBundle': 1}.
Error: none.

- MonoScript: UISettings
- MonoBehaviour: UISettings
- AssetBundle: data.unity3d
- MonoScript: AllData
- MonoBehaviour: AllData
### dlc/1383 (sept 26 2019)/android/master.unity3d

Downloaded 488287 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoBehaviour': 2, 'MonoScript': 2, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: GlobalBundleData
- MonoScript: GlobalBundleData
- MonoBehaviour: GlobalLookupData
- AssetBundle: master.unity3d
- MonoScript: GlobalLookupData
### dlc/1383 (sept 26 2019)/android/static_data.unity3d

Downloaded 905 bytes. SHA-1 verified: True.
Unity objects: 3.
Object types: {'MonoBehaviour': 2, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: staticinfo_ACD_scups
- AssetBundle: static_data.unity3d
- MonoBehaviour: staticinfo_ABC_reedling
### dlc/1428 (oct 23 2019)/android/Server

Downloaded 1253 bytes. SHA-1 verified: True.
Unity objects: 2.
Object types: {'AssetBundle': 1, 'AssetBundleManifest': 1}.
Error: none.

- AssetBundleManifest: AssetBundleManifest
### dlc/1428 (oct 23 2019)/android/data.unity3d

Downloaded 62708 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoScript': 2, 'MonoBehaviour': 2, 'AssetBundle': 1}.
Error: none.

- MonoScript: UISettings
- MonoBehaviour: UISettings
- AssetBundle: data.unity3d
- MonoScript: AllData
- MonoBehaviour: AllData
### dlc/1428 (oct 23 2019)/android/localization.unity3d

Downloaded 10791 bytes. SHA-1 verified: True.
Unity objects: 13.
Object types: {'MonoBehaviour': 8, 'MonoScript': 4, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: de
- MonoBehaviour: it
- MonoBehaviour: settings
- MonoScript: BBBMasterText
- MonoBehaviour: _master_text
- MonoBehaviour: localization
- MonoScript: BBBLanguageData
- MonoScript: BBBLocalizerSettings
- AssetBundle: localization.unity3d
- MonoScript: BBBLocalizerConfig
- MonoBehaviour: es
- MonoBehaviour: fr
- MonoBehaviour: en
### dlc/1428 (oct 23 2019)/android/master.unity3d

Downloaded 492866 bytes. SHA-1 verified: True.
Unity objects: 5.
Object types: {'MonoBehaviour': 2, 'MonoScript': 2, 'AssetBundle': 1}.
Error: none.

- MonoBehaviour: GlobalBundleData
- MonoScript: GlobalBundleData
- AssetBundle: master.unity3d
- MonoScript: GlobalLookupData
- MonoBehaviour: GlobalLookupData

**Interpretation caution:** Object names, compiler symbols and server paths do not by themselves establish scrapped gameplay.
